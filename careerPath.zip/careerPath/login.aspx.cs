﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class pages_Default2 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Login()
    {
        try
        {
            if (con.State != ConnectionState.Open)
                con.Open();

            string sql = "Select * from admin where email_id=@email and password=@password and status = @status";
           
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@email", email.Text.Trim());
            cmd.Parameters.AddWithValue("@password", password.Text.Trim() );
            cmd.Parameters.AddWithValue("@status", 0);

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Session["email"] = email.Text.Trim();
                Session["name"] = dt.Rows[0]["name"].ToString();
                Session["role"] = dt.Rows[0]["role"].ToString();
                Session["id"] = dt.Rows[0]["Admin_id"].ToString();

                if (Session["role"].ToString() == "Admin")
                Response.Redirect("./admin.aspx", false);
                else
                    Response.Redirect("./user.aspx", false);

            }
            else
            {
                Label1.Text = "Invalid Email Or Password";
                Label1.CssClass = "alert alert-danger";
            }
        }
        catch (Exception ex)
        {
            Label1.Text = "Something Went Wrong. Try Again Later..";
          //  Label1.Text = ex.Message ;

            Label1.CssClass = "alert alert-danger";
        }
        finally { }
    }



    protected void login_Click(object sender, EventArgs e)
    {
        Login();
    }
}