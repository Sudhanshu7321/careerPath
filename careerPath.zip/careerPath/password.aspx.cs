﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

public partial class pages_Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Conn"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (String.IsNullOrEmpty((string)Session["email"]))
        {
            Response.Redirect("./index.aspx", false);

        }
        
    }


    protected void check()
    {
        try
        {
            if (con.State != ConnectionState.Open)
                con.Open();

            string sql = "Select * from admin where email_id=@email";

            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@email", Session["email"].ToString());
           

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            if (dt.Rows.Count > 0)
            {


                if (password.Text.Trim() != dt.Rows[0]["password"].ToString())
                {
                    Label1.Text = "Current Password is Wrong.";
                    Label1.CssClass = "alert alert-danger";

                }
                else
                {
                    change();

                }
            }
        }
        catch (Exception ex)
        {
            Label1.Text = "Something Went Wrong. Try Again Later..";
            //  Label1.Text = ex.Message ;

            Label1.CssClass = "alert alert-danger";
        }
        finally { }
    }


    
protected void change()
    {
        try
        {
            if (con.State != ConnectionState.Open)
                con.Open();


            string sql_query = "update admin set password = @password where email_id = @email";

            SqlCommand cmd = new SqlCommand(sql_query, con);

            cmd.Parameters.AddWithValue("@email", Session["email"].ToString() );
            cmd.Parameters.AddWithValue("@password", newPassword.Text.Trim());
 

            if (cmd.ExecuteNonQuery() > 0)
            {
                Label1.Text = "Successful Change.";
                Label1.CssClass = "alert alert-success";
                password.Text = null;
                newPassword.Text = null;
             

            }

        }
        catch (Exception ex)
        {
            Label1.Text = "Something Went Wrong. Try Again Later..";
            Label1.Text = ex.Message;
            Label1.CssClass = "alert alert-danger";
        }
        finally
        {
            con.Close();
        }
    }

    protected void login_Click(object sender, EventArgs e)
    {
        check();

    }
}