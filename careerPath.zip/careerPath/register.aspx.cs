﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
public partial class pages_Default3 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Conn"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    protected void Register()
    {
        try
        {
            if (con.State != ConnectionState.Open)
                con.Open();

           
            string sql_query = "insert into admin(name, email_id,password,gender ,role, date,status) values(@name, @email,@password,@gender,@role , @date,@status)";

            SqlCommand cmd = new SqlCommand(sql_query, con);

            cmd.Parameters.AddWithValue("@name", name.Text.ToString());
            cmd.Parameters.AddWithValue("@email", email.Text.ToString());
            cmd.Parameters.AddWithValue("@password", password.Text.Trim());
            cmd.Parameters.AddWithValue("@gender", "");
            cmd.Parameters.AddWithValue("@role", "");
            cmd.Parameters.AddWithValue("@date", System.DateTime.UtcNow.ToString("MM/dd/yyyy"));
            cmd.Parameters.AddWithValue("@status", 0);

            if (cmd.ExecuteNonQuery() > 0)
            {
                Label1.Text = "Successful Created";
                Label1.CssClass = "alert alert-success";
                name.Text = null;
                email.Text = null;
                password.Text = null;

            }

        }
        catch (Exception ex)
        {
            Label1.Text = "Something Went Wrong. Try Again Later..";
            Label1.Text = ex.Message;
            Label1.CssClass = "alert alert-danger";
        }
        finally
        {
            con.Close();
        }
    }

    protected void register_Click(object sender, EventArgs e)
    {
        Register();
    }
}