﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class pages_MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (String.IsNullOrEmpty((string)Session["email"]))
        {
            log.InnerText = "Login";
            log.HRef = "./login.aspx#login";
            cources.HRef = "./login.aspx#login";
        }
        else
        {
            password.InnerText = "Password";
            password.HRef = "./password.aspx#Password";
            account.InnerText = "Account";
            if (Session["role"].ToString() == "Admin")
            {
                account.HRef = "./admin.aspx";

            }
            else
            {
                account.HRef = "./user.aspx";

            }
            account.HRef = "./user.aspx";
            log.InnerText = "Logout";
            log.HRef = "./logout.aspx";
            cources.HRef = "./cources.aspx";
        }
    }
}
